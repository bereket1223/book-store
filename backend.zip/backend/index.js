import express from "express";
import { PORT, mongoDBURL } from "./cofig.js";
import mongoose from "mongoose";
import { Book } from "./models/books.js";
import cors from 'cors';
import booksRoute from "./routes/booksRoute.js";
const app = express();

//middleware for parsing request body
app.use(express.json());

app.use(cors({
  origin:'http://localhost:5173',
  method:['POST', 'GET', 'PUT', 'DELETE'],
  allowedHeaders:['Content-Type']
}));

app.get("/", (req, res) => {
  console.log(req);
  return res.status(234).send("hi alls");
});
app.use('/books',booksRoute)

mongoose
  .connect(mongoDBURL)
  .then(() => {
    console.log("DB connected");
    app.listen(PORT, () => {
      console.log(`the server is listening to port ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(error);
  });
