export const PORT = 5555;
export const mongoDBURL =
  "mongodb+srv://root:root@book.e35py.mongodb.net/?retryWrites=true&w=majority&appName=book";
